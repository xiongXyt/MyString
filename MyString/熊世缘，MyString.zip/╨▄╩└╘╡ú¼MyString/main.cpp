#include<iostream>
#include "Mystring.h"
#include "include/XYTString.h"
#pragma comment(lib,"lib/XYTString.lib")
using namespace std;

int main() {
	char const*const number = "12345";
	MyString str(number + 1, number + 4, 10);
	MyString str2 = str;
	str2 = 'a';
	cout << str.GetString() << endl;
	cout << str.GetStrLen() << endl;
	cout << "*********************" << endl;
	cout << str2.GetString() << endl;
	cout << str2.GetStrLen() << endl;

	return 0;
}


