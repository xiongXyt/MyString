#ifndef MYSTRING_H_
#define MYSTRING_H_
#include "include/XYTString.h"
#include<iostream>
#pragma comment(lib,"lib/XYTString.lib")
using namespace std;


#define CLENGTH 10
#define STRDELETE(p) {if (p!=nullptr) {delete p; p = nullptr;}}
#define STRCLEAR(p) {if (p!=nullptr) {delete[]p; p = nullptr;}}

class MyString {

public:
	MyString();
	~MyString();

	MyString(char cchar, size_t count = 1);
	MyString(short scount, size_t count = 1);
	MyString(int icount, size_t count = 1);
	MyString(bool bcount, size_t count = 1);
	MyString(float fcount, size_t count = 1);
	MyString(double dcount, size_t count = 1);
	MyString(char const* const pstr);
	MyString(char const* const fpstr, char const* const epstr, size_t count = 1);

	MyString(MyString const& other);
	MyString(MyString const* const pother);

	MyString& operator+(char cchar);
	MyString& operator+(short scount);
	MyString& operator+(int icount);
	MyString& operator+(bool bcount);
	MyString& operator+(float fcount);
	MyString& operator+(double dcount);
	MyString& operator+(char const* const pstr);
	MyString& operator+(MyString const& other);
	MyString& operator+(MyString const* const pother);

	MyString& operator+=(char cchar);
	MyString& operator+=(short scount);
	MyString& operator+=(int icount);
	MyString& operator+=(bool bcount);
	MyString& operator+=(float fcount);
	MyString& operator+=(double dcount);
	MyString& operator+=(char const* const pstr);
	MyString& operator+=(MyString const& other);
	MyString& operator+=(MyString const* const pother);

	MyString& operator*(unsigned short scount);
	MyString& operator*(unsigned int icount);
	MyString& operator*=(unsigned short scount);
	MyString& operator*=(unsigned int icount);

	MyString& operator=(char cchar);
	MyString& operator=(short scount);
	MyString& operator=(int icount);
	MyString& operator=(bool bcount);
	MyString& operator=(float fcount);
	MyString& operator=(char const* const pstr);
	MyString& operator=(MyString const& other);
	MyString& operator=(MyString const* const pother);

	char* operator[](size_t index);
	char* operator[](size_t index)const;

	friend bool operator>(MyString const& str, MyString const& other);
	friend bool operator<(MyString const& str, MyString const& other);
	friend bool operator>=(MyString const& str, MyString const& other);
	friend bool operator<=(MyString const& str, MyString const& other);
	friend bool operator==(MyString const& str, MyString const& other);
	friend bool operator!=(MyString const& str, MyString const& other);

protected:
	void Init();
	void ClearStr();
	void AddCapacity();

public:
	int StrLen()const;
	int StrLen(char const* const str)const;
	int StrLen(MyString const& other);

	MyString& Append(char const& const str);
	MyString& Append(char const* const str);
	MyString& Append(MyString const& other);
	MyString& Append(char* str, size_t index, size_t len);
	MyString& Append(MyString const& other, size_t len);
	MyString& Append(MyString const& other, size_t index, size_t len);
	MyString& Append(char ch, size_t count);


	MyString& Aassign(char const& const str);
	MyString& Aassign(char const* const str);
	MyString& Aassign(MyString const& other);
	MyString& Aassign(char const* str, size_t index, size_t len);
	MyString& Aassign(MyString const& other, size_t len);
	MyString& Aassign(MyString const& other, size_t index, size_t len);
	MyString& Aassign(char ch, size_t count);

	char& At(size_t index);

	int Compare(MyString const& other);
	int Compare(char const* str);
	int Compare(size_t index, size_t len,
		MyString const& other, size_t index2 = 0, size_t len2 = 0);
	int Compare(size_t index, size_t len, char const* str, size_t index2 = 0, size_t len2 = 0);

	size_t Copy(char* const str, size_t count = 1, size_t index = 0);

	bool Empty()const;

	MyString& Erase(size_t index = 0, size_t count = 0);

	int Find(MyString const& other, size_t index = 0);
	int Find(char const* str, size_t index = 0);
	int Find(char const* str, size_t index, size_t len);
	int Find(char ch, size_t index = 0);

	size_t RFind(MyString const& other, size_t index = 0);
	size_t RFind(char const* str, size_t index = 0);
	size_t RFind(char const* str, size_t index, size_t len);
	size_t RFind(char ch, size_t index);

	size_t FindFirst(MyString const& other, size_t index = 0);
	size_t FindFirst(char const* str, size_t index = 0);
	size_t FindFirst(char const* str, size_t index, size_t len);
	size_t FindFirst(char ch, size_t index = 0);

	size_t FindFirstNot(MyString const& other, size_t index = 0);
	size_t FindFirstNot(char const* str, size_t index = 0);
	size_t FindFirstNot(char const* str, size_t index, size_t len);
	size_t FindFirstNot(char ch, size_t index = 0);

	size_t FindLast(MyString const& other, size_t index = 0);
	size_t FindLast(char const* str, size_t index = 0);
	size_t FindLast(char const* str, size_t index, size_t len);
	size_t FindLast(char ch, size_t index = 0);

	size_t FindLastNot(MyString const& other, size_t index = 0);
	size_t FindLastNot(char const* str, size_t index = 0);
	size_t FindLastNot(char const* str, size_t index, size_t len);
	size_t FindLastNot(char ch, size_t index = 0);

	MyString& Insert(size_t index, MyString const& other);
	MyString& Insert(size_t index, char const* str);
	MyString& Insert(size_t index1, MyString const& other, size_t index2, size_t count);
	MyString& Insert(size_t index, char const* str, size_t count);
	MyString& Insert(size_t index, size_t count, char ch);

	MyString& Replace(size_t index, size_t count, MyString const& other);
	MyString& Replace(size_t index1, size_t count1, MyString const& other, size_t index2,
		size_t count2);
	MyString& Replace(size_t index, size_t count, char const* str);
	MyString& Replace(size_t index, size_t count1, char const* str, size_t count2);
	MyString& Replace(size_t index, size_t count1, size_t count2, char ch);

	void Resize(size_t count);
	void Resize(size_t count, char ch);

	MyString Substr(size_t index, size_t count = 0);

	void Swap(MyString& other);

	char const* const GetString();
	size_t GetStrLen();
	size_t GetStrCap();
	size_t GetMaxStr();

protected:
	char* m_pstr;
	unsigned int m_strLen;
	unsigned int m_capacity;
};

#endif // !MYSTRING_H_

